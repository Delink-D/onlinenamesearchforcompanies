<div class="col-md-8" id="main">
	<div class="col_3 group">
		<div class="panel-heading">
			<h2 class="c_n_h"><?php echo $name; ?> <small>Profile</small></h2>
			<hr>
		</div>
		<div class="col-md-12 col-sm-12 group widget c_n">
            <div class="r3_counter_box group">
                <div class="prof-img">
                    
                </div>
                <div class="settings">
                	<table class="table table-bordered">
                		<tr>
                            <td>User Name</td>
                            <td><?php echo $uname; ?></td>
                            <td><input type="text" class="form-control" placeholder="Change User Name"></td>
                        </tr><tr>
                            <td>First Name</td>
                            <td><?php echo $fname; ?></td>
                            <td><input type="text" class="form-control" placeholder="Change First Name"></td>
                        </tr>
                        <tr>
                            <td>Last Name</td>
                            <td><?php echo $lname; ?></td>
                            <td><input type="text" class="form-control" placeholder="Change Last Name"></td>
                        </tr>
                        <tr>
                            <td>E-mail</td>
                            <td><?php echo $email; ?></td>
                            <td><input type="text" class="form-control" placeholder="Change Email"></td>
                        </tr>
                        <tr>
                			<td>Password</td>
                			<td>XXXXXXXXXX</td>
                			<td><input type="password" class="form-control" placeholder="Change Password"></td>
                		</tr>
                	</table>
                </div>
            </div>
        </div>
	</div>
</div>