<!DOCTYPE html>
	<html>
	<head>
		<title>Admin panel Dashboard</title>
		<!-- styles css -->
		<link rel="stylesheet" type="text/css" href="/name_search/admin/panel/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="/name_search/admin/panel/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="/name_search/admin/panel/css/style.css">

		<!-- scripts js -->
		<script type="text/javascript" src="/name_search/admin/panel/js/jquery.min.js"></script>
	</head>