<?php

	// get root server

	$server = 'http://' . $_SERVER['SERVER_NAME'] . '/namesearch/admin/panel/';