<?php

	// login check
	include 'config/check.php';

	// include head
	include 'dir/head.php';