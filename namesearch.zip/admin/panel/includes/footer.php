		<!-- Footer -->
		<footer class="container-fluid footer">
			<div class="container">
				<p>
					All rights Reserved Namesearch.com
				</p>
				<p>
					&copy; <?php echo date("Y"); ?>
				</p>
			</div>
		</footer>
		<script type="text/javascript" src="/name_search/admin/panel/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="/name_search/admin/panel/js/jquery-ui.min.js"></script>

		<script type="text/javascript" src="/name_search/admin/panel/js/custom.js"></script>
		<script type="text/javascript" src="/name_search/admin/panel/js/dist/jquery.validate.min.js"></script>
		<script type="text/javascript" src="/name_search/admin/panel/js/dist/additional-methods.min.js"></script>
	</body>
</html>