<?php
	
	error_reporting(0);
	
	// connecting with the database...

	include 'server.php';

	$host 	= 'localhost';
	$user 	= 'id1616384_delink';
	$pass 	= 'delinkdb';
	$db 	= 'id1616384_name_search';

	$connect = mysqli_connect($host, $user, '', $db);

	if (!$connect) {

		header('location: ' . $server . '/includes/reporting.php?msg=database');
		exit();
	}